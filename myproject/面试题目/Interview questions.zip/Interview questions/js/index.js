/**
 * Created by Administrator on 2015/12/20.
 */

var myMood = (function(argument){
    var mpro = function(){
        $(document.body).append("<div class='bodybackground'></div>");

        var windowobj = $(window);//��ȡ���������
        var browserWidth = windowobj.width(); //������Ŀ�
        var browserHieght = windowobj.height(); //������ĸ�
        $(".bodybackground").width(browserWidth);
        $(".bodybackground").height(browserHieght);
        $(".bodybackground").click(function(){
            $(".bodybackground").hide();
        });
        return  $(".bodybackground");
    };


    var men;
    var info = {
        sendMessage:function(){
            if(!men){
                men = new mpro();
            };

            return men;
        }
    };
    return info;
})();


var singleton = {
    init:function(){
        this.render();
        this.bind();
    },
    render:function(){
        var me = this;
        me.btna1 = $("#more");
    },
    bind:function(){
        var me = this;
        me.btna1.click(function(){
            var moodTest = myMood.sendMessage();

            moodTest.show();


            moodTest = null;
        })

    }


};

singleton.init();
