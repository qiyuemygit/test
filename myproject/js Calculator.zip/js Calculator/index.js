/**
 * Created by huang on 2015/10/16.
 */
var text = document.getElementById("text"); //计算器显示数值的内容区
var clear = document.getElementById("clear");//清除按钮
var back = document.getElementById("back");//后退按钮
var arr = [];  //记录每次输入内容的数组
var state = true;//判断计算器显示数值的内容区是否进行的Boolean

function checkStr(arr ,index,index2){
    switch (true){                        //输入符号时候判断上次输入内容，不能连续输入2次计算符号 ！
        case arr[index] == "+":
        case arr[index] == "-":
        case arr[index] == "*":
        case arr[index] == "/":
        case arr[index] == "%":
            return  state = false;
        case arr[index] == "sin":       //判断上一次输入是否sin，cos，tan，那么上2次输入是否加减乘除符号，也是为了不能输入连续2次符号
           switch (true){
               case arr[index2] == "+":
               case arr[index2] == "-":
               case arr[index2] == "*":
               case arr[index2] == "/":
               case arr[index2] == "%":
                   return  state = false;
               default :
                   return  state = true;

           }
        case arr[index] == "cos":
            switch (true){
                case arr[index2] == "+":
                case arr[index2] == "-":
                case arr[index2] == "*":
                case arr[index2] == "/":
                case arr[index2] == "%":
                    return  state = false;
                default :
                    return  state = true;

            }

        case arr[index] == "tan":
            switch (true){
                case arr[index2] == "+":
                case arr[index2] == "-":
                case arr[index2] == "*":
                case arr[index2] == "/":
                case arr[index2] == "%":
                    return  state = false;
                default :
                    return  state = true;

            }

        case arr[index] == "sqrt":
            switch (true){
                case arr[index2] == "+":
                case arr[index2] == "-":
                case arr[index2] == "*":
                case arr[index2] == "/":
                case arr[index2] == "%":
                    return  state = false;
                default :
                    return  state = true;

            }

        default :
            return  state = true;

    }
}

function MathScore (math){             //三角函数计算
    if(!isNaN(text.innerHTML)){
        text.innerHTML = math;
        return  state = false;
    }else{
        alert("计算前请确保是数字!");
        return  state = false;
    }
}


for(var j=0;j<23;j++){
    document.getElementsByTagName("button")[j].onclick=function(){
        if(this.id=="scroe"){                            //按“=”时计算结果
            if(text.innerHTML !=" "){                    // eval内容不能为空
                text.innerHTML = parseFloat( eval(text.innerHTML).toFixed(12));
                arr.push("=");
            }else{
                state = false;
            }
                                          //数组末尾添加
        }
        else {

         arr.push(this.value);                      //接受每次输入内容

         switch (true){
             case  arr[arr.length-1] == "+":
                 checkStr(arr,[arr.length-2],[arr.length-3]); //输入符号时候判断上次输入内容，不能连续输入2次计算符号 ！
                 break;

             case  arr[arr.length-1] == "-":
                 checkStr(arr,[arr.length-2],[arr.length-3]);
                 break;

             case  arr[arr.length-1] == "*":
                 checkStr(arr,[arr.length-2],[arr.length-3]);
                 break;

             case  arr[arr.length-1] == "/":
                 checkStr(arr,[arr.length-2],[arr.length-3]);
                 break;

             case  arr[arr.length-1] == "%":
                 checkStr(arr,[arr.length-2],[arr.length-3]);
                 break;

             case arr[arr.length-1] == "0":               //每次输入“0”，都判断是不是除数！
                 if(arr[arr.length-2]== "/"){
                     state = false;
                     alert("除数不能为0");
                 }
                 break;

             case arr[arr.length-1] == "sin":
                 MathScore (Math.sin(text.innerHTML));
                 break;

             case arr[arr.length-1] == "cos":
                 MathScore (Math.cos(text.innerHTML));
                 break;

             case arr[arr.length-1] == "tan":
                 MathScore (Math.tan(text.innerHTML));
                 break;

             case arr[arr.length-1] == "sqrt":
                 MathScore (Math.sqrt(text.innerHTML));
                 break;

             default :
                 if(arr[arr.length-2] == "="){             //按 “=”后，再输入数字就清除内容
                     text.innerHTML = " ";
                     arr.length = 0;
                 }else{
                     state = true;
                 }
                 break;
         }


          if(state){
                text.innerHTML+=this.value;
          }

        }
    }
}

clear.onclick = function(){   //清除按钮
    text.innerHTML = " ";
};

back.onclick = function(){     //后退按钮
    var obj = text.innerHTML;
    text.innerHTML = obj.replace(/.$/,'');
};


