<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>链接数据库</title>
</head>
<body>
<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2015/11/14
 * Time: 21:41
 */
$conn = @mysql_connect('localhost','root','');

if(!$conn){
    echo '连接失败';
}else{

   mysql_select_db('PHPlesson',$conn);

    mysql_query("set names 'utf8'");

   $result =  mysql_query('SELECT * FROM news');

//   $result_arr = mysql_fetch_assoc( $result);
//
//    print_r($result_arr);
//
//    $result_arr = mysql_fetch_assoc( $result);
//
//    print_r($result_arr);

//    echo '数据条数'.mysql_num_rows($result);

//    $data_count = mysql_num_rows($result);
//    for($i=0;$i<$data_count;$i++){
//        print_r(mysql_fetch_assoc($result));
//    }



}
?>
</body>
</html>