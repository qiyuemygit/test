<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2015/11/14
 * Time: 22:26
 */

define('MYSOL_HOST','localhost');
define('MYSOL_USER','root');
define('MYSOL_PW','');