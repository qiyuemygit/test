<?php
require_once 'function.php'
?>

<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8"/>
    <title>后台信息管理系统 </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.css" type="text/css">
    <link rel="stylesheet" href="css/bootstrap-responsive.css" type="text/css">
    <link rel="stylesheet" href="css/main.css" type="text/css">
</head>
<body>

<div class="container-fluid">
    <!-------头部标题---------->
    <div class="row-fluid">
        <div class="header span12">
            <img src="img/header01.gif">
            <span><strong>新闻信息管理系统</strong></span>
        </div>
    </div>
    <!-------头部标题---end------->
    <div class="row-fluid">
        <!----left--按钮导航框----->
        <div class="span3 hidden-phone">
            <div class="box">
                超级管理员：admin
            </div>
            <!------用户信息管理------>
            <div class="box">
                <div class="title"><strong>用户信息管理</strong></div>
                <div class="accordion" id="accordion2">
                    <div class="accordion-group">
                        <div class="accordion-heading">
                            <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseOne">
                                用户信息查询
                            </a>
                        </div>
                        <div id="collapseOne" class="accordion-body collapse in">
                            <div class="accordion-inner">
                                <a href="#" class="color_text">精确查询</a>
                            </div>
                            <div class="accordion-inner">
                                <a href="#" class="color_text">组合条件查询</a>
                            </div>
                        </div>
                    </div>
                    <div class="accordion-group">
                        <div class="accordion-heading">
                            <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseTwo">
                                用户密码管理
                            </a>
                        </div>
                        <div id="collapseTwo" class="accordion-body collapse">
                            <div class="accordion-inner">
                                <a href="#" class="color_text">找回密码</a>
                            </div>
                            <div class="accordion-inner">
                                <a href="#" class="color_text">更改密码</a>
                            </div>
                            <div class="accordion-inner">
                                <a href="#" class="color_text">密码加密</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!------用户信息管理--end---->
            <!--------用户分析------->
            <div class="box">
                <div class="title"><strong>用户分析</strong></div>
                <div class="accordion" id="accordion3">
                    <div class="accordion-group">
                        <div class="accordion-heading">
                            <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion3" href="#collapsethree">
                                用户注册统计
                            </a>
                        </div>
                        <div id="collapsethree" class="accordion-body collapse">
                            <div class="accordion-inner">
                                Anim pariatur cliche...
                            </div>
                        </div>
                    </div>

                    <div class="accordion-group">
                        <div class="accordion-heading">
                            <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion3" href="#collapsefour">
                                用户登录统计
                            </a>
                        </div>
                        <div id="collapsefour" class="accordion-body collapse">
                            <div class="accordion-inner">
                                Anim pariatur cliche...
                            </div>
                        </div>
                    </div>

                    <div class="accordion-group">
                        <div class="accordion-heading">
                            <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion3" href="#collapsefive">
                                用户激活统计
                            </a>
                        </div>
                        <div id="collapsefive" class="accordion-body collapse">
                            <div class="accordion-inner">
                                Anim pariatur cliche...
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--------用户分析--end----->
            <!--------系统管理------->
            <div class="box">
                <div class="title"><strong>系统管理</strong></div>
                <div class="accordion" id="accordion4">
                    <div class="accordion-group">
                        <div class="accordion-heading">
                            <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion4" href="#collapsesix">
                                权限管理
                            </a>
                        </div>
                        <div id="collapsesix" class="accordion-body collapse ">
                            <div class="accordion-inner">
                                Anim pariatur cliche...
                            </div>
                        </div>
                    </div>

                    <div class="accordion-group">
                        <div class="accordion-heading">
                            <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion4" href="#collapseseven">
                                用户组管理
                            </a>
                        </div>
                        <div id="collapseseven" class="accordion-body collapse">
                            <div class="accordion-inner">
                                Anim pariatur cliche...
                            </div>
                        </div>
                    </div>

                    <div class="accordion-group">
                        <div class="accordion-heading">
                            <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion4" href="#collapseeight">
                                操作日志
                            </a>
                        </div>
                        <div id="collapseeight" class="accordion-body collapse">
                            <div class="accordion-inner">
                                Anim pariatur cliche...
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--------系统管理--end----->
            <div class="box"><a href="system.html">安全退出</a></div>
        </div>
        <!----left--按钮导航框-end---->
        <!----right------->
        <div class="span9">
            <!---小于767px显示区---->
            <div class="nav nav-tabs  visible-phone  ">
                <ul class="nav ">
                    <li class="active btn-group">
                        <a href="#" class="btn dropdown-toggle" data-toggle="dropdown">
                            用户信息
                            <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="#" class="color_text">用户信息查询</a></li>
                            <li><a href="#" class="color_text">用户密码管理</a></li>
                        </ul>
                    </li>

                    <li class="btn-group active">
                        <a href="#" class="btn dropdown-toggle" data-toggle="dropdown">
                            用户分析
                            <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="#" class="color_text">用户注册统计</a></li>
                            <li><a href="#" class="color_text">用户登录统计</a></li>
                            <li><a href="#" class="color_text">用户激活统计</a></li>
                        </ul>
                    </li>

                    <li class="btn-group active">
                        <a href="#" class="btn dropdown-toggle" data-toggle="dropdown">
                            系统管理
                            <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu active">
                            <li><a href="#" class="color_text">权限管理</a></li>
                            <li><a href="#" class="color_text">用户组管理</a></li>
                            <li><a href="#" class="color_text">操作日志</a></li>
                        </ul>
                    </li>

                    <li class="btn-group active"><a href="index.html" class="btn active">推出</a></li>
                </ul>
            </div>
            <!---小于767px显示区-end--->
            <div class="big_box">

                <a href="addnews.html" class="label label-info">添加新闻</a>
                <table class=" table table-hover">
                    <caption class="info"><strong>新闻信息管理</strong></caption>
                    <tr>
                        <th>id</th>
                        <th>新闻题目</th>
                        <th>图片</th>
                        <th>内容</th>
                        <th>时间</th>
                        <th>修改</th>
                    </tr>
                    <?php
                    /**
                     * Created by PhpStorm.
                     * User: Administrator
                     * Date: 2015/11/14
                     * Time: 21:41
                     */

                    $conn = connectDb();



                    mysql_query("set names 'utf8'");

                    $result = mysql_query("SELECT * FROM news ORDER BY newsid DESC");

                    $dataCount = mysql_num_rows($result);

                    for($i=0;$i<$dataCount;$i++){
                        $result_arr = mysql_fetch_assoc($result);

                        $id = $result_arr['newsid'];
                        $newstitle = $result_arr['newstitle'];
                        $newsimg = $result_arr['newsimg'];
                        $newcontent = $result_arr['newcontent'];
                        $addtime = $result_arr['addtime'];

                        echo "<tr>
                               <td>$id</td>
                                <td>$newstitle</td>
                               <td>$newsimg</td>
                               <td>$newcontent</td>
                               <td>$addtime</td>
                               <td>
                                  <a href='editnews.php?id=$id'>修改</a>
                                 <a href='deletenews.php?id=$id'>删除</a>
                                </td>
                             </tr>";

                           //    print_r($result_arr);

                    }
                    ?>



            </div>
            <!-------分页-------->
<!--            <div>-->
<!--                <ul class="pager .pagination-centered pagination">-->
<!--                    <li class="disabled"><a>首页</a></li>-->
<!--                    <li class="disabled"><a>上一页</a></li>-->
<!--                    <li><a href="#">下一页</a></li>-->
<!--                    <li><a href="#">尾页</a></li>-->
<!--                </ul>-->
<!--            </div>-->
            <!-------分页-end------->
        </div>
        <!----right--end----->


    </div>
</div>

<script src="jquery.js"></script>
<script src="bootstrap.min.js"></script>
</body>
</html>