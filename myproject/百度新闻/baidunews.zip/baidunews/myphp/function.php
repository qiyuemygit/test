<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2015/11/14
 * Time: 22:27
 */

require_once 'config.php';

function connectDb(){
    $conn = mysql_connect(MYSOL_HOST,MYSOL_USER,MYSOL_PW);
    if( !$conn){
        die('Can not connect db');
    }
    mysql_select_db('PHPlesson');
    return $conn;
}