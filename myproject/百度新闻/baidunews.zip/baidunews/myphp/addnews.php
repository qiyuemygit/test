<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2015/11/15
 * Time: 10:18
 */

if(!isset($_POST['newstitle'])){
    die('newstitle not difinde');
}

if(!isset($_POST['newsimg'])){
    die('newsimg not difinde');
}

if(!isset($_POST['newcontent'])){
    die('newcontent not difinde');
}

if(!isset($_POST['addtime'])){
    die('addtime not difinde');
}

$newstitle = $_POST['newstitle'];

$newsimg = $_POST['newsimg'];

$newcontent = $_POST['newcontent'];

$addtime = $_POST['addtime'];

require_once 'function.php';

 connectDb();

mysql_query("set names 'utf8'");

mysql_query("INSERT INTO `news`( `newstitle`, `newsimg`, `newcontent`, `addtime`) VALUES ('$newstitle','$newsimg','$newcontent','$addtime') ");

if(mysql_errno()){
    echo mysql_errno();
}

header('location:allnews.php');
