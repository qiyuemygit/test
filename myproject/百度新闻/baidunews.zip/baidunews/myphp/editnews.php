<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title>编辑新闻</title>
</head>
<body>


<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2015/11/15
 * Time: 12:06
 */

//if(isset($_GET['id'])&&!empty($_GET['id'])){
//
//}
require_once 'function.php';

if(!empty($_GET['id'])){

    connectDb();

    mysql_query("set names 'utf8'");

    $id = intval($_GET['id']);

    $result = mysql_query("SELECT * FROM news WHERE newsid = $id");

    if(mysql_errno()){
        die('can not connect db');
    }

    $arr = mysql_fetch_assoc(  $result);

//    print_r($arr);

}else{
    die('id not define');
}
?>

<form action="enditnews_server.php" method="post">
    <p>
        <label for="newstitle">新闻序号</label>
        <input type="text" id="newstitle" name="newsid" value="<?php echo $arr['newsid'];?>">
    </p>
    <p>
        <label for="newstitle">新闻标题</label>
        <input type="text" id="newstitle" name="newstitle" value="<?php echo $arr['newstitle'];?>">
    </p>
    <p>
        <label for="newsimg">图片地址</label>
        <input type="text" id="newsimg" name="newsimg"  value="<?php echo $arr['newsimg'];?>">
    </p>
    <p>
        <label for="newcontent">新闻内容</label>
        <textarea id="newcontent" name="newcontent" ></textarea>
    </p>
    <p>
        <label for="addtime">新闻时间</label>
        <input type="text" id="addtime" name="addtime" value="<?php echo $arr['addtime'];?>"/>
    </p>
    <p>
        <input type="submit" value="提交修改"/>
        <input type="reset" value="重置"/>
    </p>
</form>

<script>
    document.getElementById("newcontent").value = "<?php echo $arr['newcontent'];?>";
</script>
</body>
</html>





