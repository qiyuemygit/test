<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2015/11/15
 * Time: 13:34
 */

if(empty($_GET['id'])){
    die('id is empty');
}

require_once 'function.php';

connectDb();
mysql_query("set names 'utf8'");

$id =intval( $_GET['id']);

mysql_query("DELETE FROM `news` WHERE newsid = $id");

if(mysql_errno()){
    die("fail to delete news with id $id");
}else{
    header("location:allnews.php");
}
