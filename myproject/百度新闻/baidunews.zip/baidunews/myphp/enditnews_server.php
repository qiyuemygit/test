<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2015/11/15
 * Time: 12:26
 */

require_once 'function.php';

if(empty($_POST['newsid'])){
    die('newsid is empty');
}

if(empty($_POST['newstitle'])){
    die('newstitle is empty');
}

if(empty($_POST['newsimg'])){
    die('newsimg is empty');
}

if(empty($_POST['newcontent'])){
    die('newcontent is empty');
}

if(empty($_POST['addtime'])){
    die('addtime is empty');
}

$id = intval($_POST['newsid']);
$newstitle = $_POST['newstitle'];
$newsimg = $_POST['newsimg'];
$newcontent = $_POST['newcontent'];
$addtime =  $_POST['addtime'];

connectDb();
mysql_query("set names 'utf8'");

mysql_query("UPDATE `news` SET `newstitle`='$newstitle',`newsimg`='$newsimg',`newcontent`='$newcontent',`addtime`='$addtime' WHERE `newsid`=$id");

if(mysql_errno()){
    echo mysql_errno();
}else{
    header('location:allnews.php');
}