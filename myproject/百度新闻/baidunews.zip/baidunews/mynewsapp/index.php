<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2015/11/11
 * Time: 21:46
 */
header("Content-Type:text/event-stream;charset=utf-8");
//header("Content-type:appliacation/json;charset = utf-8");
//header('Access-Control-Allow-Origin:http://127.0.0.1');
//echo "data:现在时间是".date('H:i:s')."\r\n\r\n";





$con = mysql_connect("localhost","root","");
mysql_query("set names 'utf8' ");
mysql_query("set character_set_client=utf8");
mysql_query("set character_set_results=utf8");
if (!$con)
{
    die('Could not connect: ' . mysql_error());
}else{

    mysql_select_db("PHPlesson",$con);

    $sql = "SELECT * FROM news";
    $result = mysql_query($sql);



    $arr = array();
    while($row = mysql_fetch_array($result))
    {
//        echo $row['newstitle']." ".$row['newsimg'];

        array_push($arr,array("newstitle"=>$row['newstitle'],"newsimg"=>$row['newsimg'],"newcontent"=>$row['newcontent'],"addtime"=>$row['addtime']));
    }
//    print_r($arr);
//    echo json_encode($arr);

    echo "data:".json_encode($arr,JSON_UNESCAPED_UNICODE)."\r\n\r\n";



}



mysql_close($con);

?>