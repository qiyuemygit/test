var source;

var state = true;//数据加载状态

function init(){
    source = new EventSource('http://localhost/mynewsapp/index.php');
    source.onopen = function(){
        console.log('链接已成立',this.readyState);

        //alert("正在加载...")//测试
    };
    source.onmessage = function(){
        //console.log(event.data);

        var json = event.data;

        var  myjson = $.parseJSON(json);
        //console.log(myjson);//返回是数组
        //console.log(myjson[0].newstitle);//标题
        //console.log(myjson[0].newcontent);//内容
        //console.log(myjson[0].newsimg);//图片

        //修改新闻
          var newstitle =  $(".newstitle");//新闻标题
          var newscontent = $(".newscontent");//新闻内容
          var newsimg = $(".newsimg");//新闻图片


          for(var i = 0; i<myjson.length;i++){
              newstitle.eq(i).html(myjson[i].newstitle)//修改新闻标题
              newscontent.eq(i).html(myjson[i].newcontent)//修改新闻标题
              newsimg.eq(i).attr('src',myjson[i].newsimg)//修改新闻标题

          }



        if(true){ //添加news

            var i = 0;
            i = $(".box").length;

            for(  ; i<myjson.length;i++){
                var box = $("<div>").addClass("box").appendTo($(".addbox"));
                var box_img = $("<div>").addClass("box_img").appendTo(box);
                $("<img>").addClass("newsimg").attr('src',myjson[i].newsimg).appendTo(box_img);

               var box_title = $("<div>").addClass("box_title").appendTo(box);
                $("<h6>").addClass("newstitle").html(myjson[i].newstitle).appendTo(box_title);
                $("<p>").addClass("newscontent").html(myjson[i].newcontent).appendTo(box_title);
            }

        }

        var boxnum = $(".box").length;
        if(boxnum>myjson.length){        //如果盒子个数少于myjson个数，把多余的删除；
            for(var i = myjson.length;i<boxnum;i++){
                $(".box").eq(i).remove();
            }
        }




        $(".loadimg").css("display","none")//关闭loadimg，动画

    };
    source.onerror = function(){

    };
}

//init();




$("#btn").click(function(){
    $(".loadimg").css("display","block")//加载数据loadimg，动画
    init();
});



//CREATE TABLE `phplesson`.`news` ( `newsid` INT NOT NULL AUTO_INCREMENT , `newstitle` VARCHAR(100) NOT NULL , `newsimg` VARCHAR(200) NOT NULL , `newcontent` TEXT NOT NULL , `addtime` DATE NOT NULL , PRIMARY KEY (`newsid`) , INDEX (`newstitle`) ) ENGINE = InnoDB COMMENT = '新闻表';




